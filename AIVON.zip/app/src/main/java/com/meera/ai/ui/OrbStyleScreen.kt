@file:OptIn(ExperimentalMaterial3Api::class)

package com.meera.ai.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.Meera
import com.meera.ai.ui.orb.HACKER_COLORS
import com.meera.ai.ui.orb.ORB_PALETTE_NAMES
import com.meera.ai.ui.orb.ORB_STYLE_NAMES
import com.meera.ai.ui.orb.OrbConfig
import com.meera.ai.ui.orb.OrbState
import com.meera.ai.ui.orb.OrbView
import com.meera.ai.ui.orb.orbConfigFromSettings
import com.meera.ai.ui.orb.orbSwatch
import kotlinx.coroutines.delay

private val PANEL = Color(0xFF04061A)

/** Pick one of the 20 orb styles and customise colours, size, speed, glow and background. Every change is saved at once. */
@Composable
fun OrbStyleScreen(onBack: () -> Unit) {
    val s = Meera.settings
    var cfg by remember { mutableStateOf(orbConfigFromSettings()) }
    var random by remember { mutableStateOf(s.orbRandom) }
    var pstate by remember { mutableStateOf(OrbState.SPEAK) }
    var testing by remember { mutableStateOf(false) }
    var askReset by remember { mutableStateOf(false) }

    fun commit(n: OrbConfig) {
        cfg = n
        s.orbStyle = n.style; s.orbPalette = n.palette
        s.orbColA = n.colA; s.orbColB = n.colB; s.orbColC = n.colC; s.orbColL = n.colL
        s.orbGain = n.gain; s.orbSpeed = n.speed; s.orbGlow = n.glow; s.orbSize = n.size
        s.orbBg = n.bg; s.orbLowFx = n.lowFx
    }

    LaunchedEffect(testing) {
        if (testing) {
            val steps = listOf(OrbState.IDLE to 1500L, OrbState.LISTEN to 2000L, OrbState.THINK to 2000L, OrbState.SPEAK to 4000L)
            for ((st, ms) in steps) { pstate = st; delay(ms) }
            pstate = OrbState.SPEAK
            testing = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
            Text("Call screen style", fontSize = 20.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
        }
        // live preview stays on top while the controls scroll underneath
        Box(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(230.dp)
                .clip(RoundedCornerShape(20.dp)).background(PANEL)
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp)),
            contentAlignment = Alignment.Center
        ) {
            OrbView(pstate, cfg, Modifier.fillMaxSize(), simulate = true)
            Text(
                ORB_STYLE_NAMES[cfg.style], color = Color(0xCCFFFFFF), fontSize = 12.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
            )
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((st, label) in listOf(OrbState.IDLE to "Tayyar", OrbState.LISTEN to "Sun rahi", OrbState.THINK to "Soch rahi", OrbState.SPEAK to "Bol rahi")) {
                FilterChip(selected = pstate == st && !testing, onClick = { testing = false; pstate = st }, label = { Text(label, fontSize = 11.sp) })
            }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Button(onClick = { testing = true }, enabled = !testing, modifier = Modifier.fillMaxWidth()) {
                    Text(if (testing) "Test chal raha hai..." else "Test: tayyar, sun rahi, soch rahi, bol rahi")
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OrbTitle("Colours")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        for (i in 0..4) {
                            val (c1, c2) = if (cfg.style == 2 && i < 4) Pair(HACKER_COLORS[i], HACKER_COLORS[i]) else orbSwatch(i, cfg)
                            val sel = cfg.palette == i
                            Box(
                                Modifier.size(42.dp).clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(c1, c2)))
                                    .border(if (sel) BorderStroke(3.dp, Color.White) else BorderStroke(1.dp, Color(0x55FFFFFF)), CircleShape)
                                    .clickable { commit(cfg.copy(palette = i)) }
                            )
                        }
                    }
                    Text(
                        "Palette: " + ORB_PALETTE_NAMES[cfg.palette] + if (cfg.style == 2) "  (Hacker HUD uses Matrix, Cyber, Red, Violet)" else "",
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (cfg.palette == 4) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OrbTitle("Custom colours")
                        ColorRow("Colour 1", cfg.colA) { commit(cfg.copy(colA = it)) }
                        ColorRow("Colour 2", cfg.colB) { commit(cfg.copy(colB = it)) }
                        ColorRow("Colour 3", cfg.colC) { commit(cfg.copy(colC = it)) }
                        ColorRow("Gold / metal", cfg.colL) { commit(cfg.copy(colL = it)) }
                        Text(
                            "Hacker HUD uses only Colour 1. Gold Luxe uses Gold / metal.",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    OrbTitle("Adjust")
                    OrbSlider("Awaaz ki shiddat", cfg.gain, 0.3f, 1.6f) { commit(cfg.copy(gain = it)) }
                    OrbSlider("Speed", cfg.speed, 0.5f, 2f) { commit(cfg.copy(speed = it)) }
                    OrbSlider("Glow", cfg.glow, 0f, 1.5f) { commit(cfg.copy(glow = it)) }
                    OrbSlider("Size", cfg.size, 0.7f, 1.2f) { commit(cfg.copy(size = it)) }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OrbTitle("Background")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = cfg.bg == 1, onClick = { commit(cfg.copy(bg = 1)) }, label = { Text("App background", fontSize = 12.sp) })
                        FilterChip(selected = cfg.bg == 0, onClick = { commit(cfg.copy(bg = 0)) }, label = { Text("Black", fontSize = 12.sp) })
                        FilterChip(selected = cfg.bg == 2, onClick = { commit(cfg.copy(bg = 2)) }, label = { Text("Deep blue", fontSize = 12.sp) })
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    SwitchRow("Low effects (slow phones)", "Fewer particles, no glow, 20 fps", cfg.lowFx) { commit(cfg.copy(lowFx = it)) }
                    SwitchRow("Random style every call", "A new style each time a call starts", random) { random = it; s.orbRandom = it }
                    OutlinedButton(onClick = { askReset = true }, modifier = Modifier.fillMaxWidth()) { Text("Reset to defaults") }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) { OrbTitle("All 20 styles (tap to choose)") }
            items(ORB_STYLE_NAMES.size) { i ->
                val sel = cfg.style == i
                Column(Modifier.clickable { commit(cfg.copy(style = i)) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(PANEL)
                            .border(if (sel) BorderStroke(2.dp, Cyan) else BorderStroke(1.dp, Color(0x33FFFFFF)), RoundedCornerShape(16.dp))
                    ) {
                        OrbView(OrbState.LISTEN, cfg.copy(style = i, lowFx = true), Modifier.fillMaxSize(), simulate = true)
                    }
                    Text(
                        "${i + 1}. ${ORB_STYLE_NAMES[i]}", fontSize = 12.sp,
                        color = if (sel) Cyan else MaterialTheme.colorScheme.onSurface,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }

    if (askReset) {
        AlertDialog(
            onDismissRequest = { askReset = false },
            title = { Text("Reset orb settings?") },
            text = { Text("Style, colours, size, speed, glow and background go back to the defaults.") },
            confirmButton = {
                TextButton(onClick = { s.resetOrb(); cfg = orbConfigFromSettings(); random = s.orbRandom; askReset = false }) { Text("Reset") }
            },
            dismissButton = { TextButton(onClick = { askReset = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun OrbTitle(text: String) {
    Text(text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun OrbSlider(label: String, value: Float, from: Float, to: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 13.sp)
            Text(((value * 100f).toInt() / 100f).toString(), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(value = value.coerceIn(from, to), onValueChange = onChange, valueRange = from..to)
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp)
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = on, onCheckedChange = onChange)
    }
}

/** Colour editor: swatch, hex field and hue / saturation / brightness sliders. */
@Composable
private fun ColorRow(label: String, argb: Int, onChange: (Int) -> Unit) {
    val hsv = remember(argb) { FloatArray(3).also { android.graphics.Color.colorToHSV(argb, it) } }
    var hex by remember(argb) { mutableStateOf(String.format("#%06X", argb and 0xFFFFFF)) }
    val valid = Regex("^#?[0-9A-Fa-f]{6}$").matches(hex.trim())
    Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(argb)).border(1.dp, Color(0x55FFFFFF), CircleShape))
            Spacer(Modifier.width(10.dp))
            Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
            OutlinedTextField(
                value = hex,
                onValueChange = { v ->
                    hex = v
                    val t = v.trim().removePrefix("#")
                    if (t.length == 6) t.toIntOrNull(16)?.let { onChange(0xFF000000.toInt() or it) }
                },
                isError = !valid, singleLine = true, modifier = Modifier.width(130.dp)
            )
        }
        Slider(
            value = hsv[0], onValueChange = { onChange(android.graphics.Color.HSVToColor(floatArrayOf(it, hsv[1], hsv[2]))) },
            valueRange = 0f..360f
        )
        Slider(
            value = hsv[1], onValueChange = { onChange(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], it, hsv[2]))) },
            valueRange = 0f..1f
        )
        Slider(
            value = hsv[2], onValueChange = { onChange(android.graphics.Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], it))) },
            valueRange = 0f..1f
        )
    }
}

package com.meera.ai.automation

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.meera.ai.Meera
import com.meera.ai.ToolOut
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

/**
 * Talks to the Termux app through its official RUN_COMMAND intent. Everything is OFF until the user switches on
 * Settings -> Termux control and finishes the one-time setup (allow-external-apps and the Android permission).
 * Commands come only from the user's own request; risky ones always ask yes / no first (Meera.confirmThen).
 */
object TermuxBridge {
    private const val PKG = "com.termux"
    private const val PERM = "com.termux.permission.RUN_COMMAND"
    const val HOME = "/data/data/com.termux/files/home"
    private const val BASH = "/data/data/com.termux/files/usr/bin/bash"

    class Result(val exit: Int?, val stdout: String, val stderr: String, val error: String?, val timedOut: Boolean)

    private val waiting = ConcurrentHashMap<Int, CompletableDeferred<Bundle?>>()
    private val nextId = AtomicInteger(1000)

    /** What the last command did (used by task_verify). */
    @Volatile var lastExit: Int? = null
    @Volatile var lastOut: String = ""
    @Volatile var lastCommand: String = ""

    fun installed(ctx: Context): Boolean =
        try { ctx.packageManager.getPackageInfo(PKG, 0); true } catch (e: Exception) { false }

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, PERM) == PackageManager.PERMISSION_GRANTED

    const val PERMISSION_NAME = PERM

    // ───────────── running a command ─────────────

    suspend fun exec(command: String, workdir: String? = null, timeoutS: Int = 60): Result {
        val ctx = Meera.app
        if (!installed(ctx)) return Result(null, "", "", "Termux is not installed. Get it from F-Droid or GitHub (not Google Play).", false)
        if (!hasPermission(ctx)) return Result(null, "", "", "The Android permission 'Run commands in Termux environment' is not allowed yet. Open Settings -> Termux control and allow it.", false)
        val id = nextId.incrementAndGet()
        val d = CompletableDeferred<Bundle?>()
        waiting[id] = d
        try {
            val flags = PendingIntent.FLAG_ONE_SHOT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pi = PendingIntent.getBroadcast(ctx, id, Intent(ctx, TermuxResultReceiver::class.java).putExtra("rid", id), flags)
            val it = Intent()
                .setClassName(PKG, "com.termux.app.RunCommandService")
                .setAction("com.termux.RUN_COMMAND")
                .putExtra("com.termux.RUN_COMMAND_PATH", BASH)
                .putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", command))
                .putExtra("com.termux.RUN_COMMAND_WORKDIR", workdir ?: HOME)
                .putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
                .putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
            ctx.startForegroundService(it)
        } catch (e: SecurityException) {
            waiting.remove(id)
            return Result(null, "", "", "Android refused: the Termux permission is missing. Allow it in Settings -> Termux control.", false)
        } catch (e: Exception) {
            waiting.remove(id)
            return Result(null, "", "", "Could not reach Termux: " + (e.message ?: e.javaClass.simpleName) + ". Open Termux once and try again.", false)
        }
        val b = try { withTimeoutOrNull(timeoutS.coerceIn(3, 600) * 1000L) { d.await() } } finally { waiting.remove(id) }
        lastCommand = command
        if (b == null) {
            lastExit = null
            return Result(null, "", "", null, true)
        }
        val out = b.getString("stdout") ?: ""
        val err = b.getString("stderr") ?: ""
        val code = if (b.containsKey("exitCode")) b.getInt("exitCode") else null
        val errCode = b.getInt("err", -1)
        val errMsg = b.getString("errmsg")
        var error: String? = null
        if (errCode != -1 && errCode != 0 && !errMsg.isNullOrBlank()) {
            error = if (errMsg.contains("allow-external-apps", true))
                "Termux blocked the command: allow-external-apps is not on. Run in Termux: mkdir -p ~/.termux && echo \"allow-external-apps=true\" >> ~/.termux/termux.properties && termux-reload-settings (then restart Termux)."
            else errMsg
        }
        lastExit = code
        lastOut = out
        TermuxHistory.add(command, code, if (out.isNotBlank()) out else err)
        return Result(code, out, err, error, false)
    }

    internal fun complete(id: Int, bundle: Bundle?) { waiting[id]?.complete(bundle) }

    fun format(r: Result): String {
        r.error?.let { return "FAILED to run: $it" }
        if (r.timedOut) return "TIMEOUT: no result in time. The command may still be running inside Termux. For long work use termux_job_start."
        val sb = StringBuilder("exit=").append(r.exit ?: "?").append('\n')
        if (r.stdout.isNotBlank()) sb.append("stdout:\n").append(cut(mask(r.stdout))).append('\n')
        if (r.stderr.isNotBlank()) sb.append("stderr:\n").append(cut(mask(r.stderr))).append('\n')
        if (r.exit != null && r.exit != 0) sb.append("(non-zero exit code: the command FAILED)")
        return sb.toString().trim()
    }

    /** Keep the start and the end of long output (about 4000 characters in total). */
    fun cut(s: String, max: Int = 4000): String =
        if (s.length <= max) s else s.take(max / 2) + "\n...[cut " + (s.length - max) + " characters]...\n" + s.takeLast(max / 2)

    private val SECRETS = listOf(
        Regex("AIza[0-9A-Za-z_\\-]{20,}"),
        Regex("gh[pousr]_[A-Za-z0-9]{20,}"),
        Regex("sk-[A-Za-z0-9_\\-]{20,}"),
        Regex("-----BEGIN [A-Z ]*PRIVATE KEY-----[\\s\\S]*?(-----END [A-Z ]*PRIVATE KEY-----|$)")
    )
    private val KEYVAL = Regex("(?i)(api[_-]?key|token|secret|passwd|password)(\\s*[=:]\\s*)\\S+")

    /** Hide API keys, tokens and passwords so they never reach the model, the screen or speech. */
    fun mask(s: String): String {
        var t = s
        for (r in SECRETS) t = r.replace(t, "***")
        return KEYVAL.replace(t) { it.groupValues[1] + it.groupValues[2] + "***" }
    }

    // ───────────── safety ─────────────

    private val RISKY = listOf(
        Regex("\\brm\\s+(-[a-zA-Z]*\\s+)*-[a-zA-Z]*[rR]"), Regex("\\brm\\s+--recursive"),
        Regex("\\bdd\\b"), Regex("\\bmkfs"), Regex("\\bchmod\\s+(-[a-zA-Z]*\\s+)*-[a-zA-Z]*R"), Regex("\\bchown\\s+(-[a-zA-Z]*\\s+)*-[a-zA-Z]*R"),
        Regex("git\\s+push\\b.*(\\s-f\\b|--force)"), Regex("git\\s+reset\\s+--hard"), Regex("git\\s+clean\\s+-[a-zA-Z]*f"),
        Regex("(curl|wget)\\b[^|;]*\\|\\s*(sh|bash|zsh)\\b"), Regex("\\b(sudo|su)\\b"),
        Regex("\\bpkg\\s+(uninstall|remove|autoclean)"), Regex("\\bapt(-get)?\\s+(remove|purge|autoremove)"),
        Regex("\\.ssh\\b|id_rsa|id_ed25519|\\.netrc|git-credentials|\\.aws/|\\.env\\b"),
        Regex("\\b(scp|rsync|ssh|nc|ncat|telnet|ftp)\\b"), Regex("\\bcurl\\b.*(\\s-d\\b|--data|\\s-F\\b|--upload-file|\\s-T\\b|--form)"),
        Regex("\\bwget\\b.*--post"), Regex("\\b(shutdown|reboot|poweroff)\\b"), Regex("\\b(pkill|killall)\\b|\\bkill\\s+-9"),
        Regex(">\\s*/(sdcard|storage)/?\\s*$"), Regex("\\btermux-(sms-send|telephony-call|call-log|contact-list|sms-list)\\b")
    )

    /** Returns a short reason if the command needs the user's yes first, otherwise null. */
    fun risky(command: String): String? {
        for (r in RISKY) if (r.containsMatchIn(command)) return "matches a dangerous pattern"
        return null
    }

    private val SENSITIVE_PATH = Regex("(?i)\\.ssh|id_rsa|id_ed25519|\\.netrc|git-credentials|\\.aws|\\.env\\b|token|passw|secret|\\.bashrc|\\.profile|\\.zshrc|/etc/|\\.\\./|/data/data/(?!com\\.termux/)")

    private fun sensitivePath(p: String): Boolean = SENSITIVE_PATH.containsMatchIn(p) ||
        !(p.startsWith("~/") || p == "~" || p.startsWith("$HOME/") || p.startsWith("./") || !p.startsWith("/"))

    // ───────────── shell helpers ─────────────

    private fun sq(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    /** A path as a safe shell word; a leading ~ still expands to the Termux home. */
    private fun shPath(p: String): String = when {
        p == "~" -> "\"\$HOME\""
        p.startsWith("~/") -> "\"\$HOME\"/" + sq(p.drop(2))
        else -> sq(p)
    }

    private fun newJobId(): String = (100000 + (System.nanoTime() % 900000).toInt().let { if (it < 0) -it else it } % 900000).toString()

    private fun jobCommand(id: String, command: String, workdir: String?): String {
        val cd = if (workdir.isNullOrBlank()) "" else "cd " + shPath(workdir) + " && "
        val body = "# meera_job_$id\n$cd$command"
        return "mkdir -p ~/meera_jobs/$id && (nohup bash -lc " + sq(body) + " > ~/meera_jobs/$id/out.log 2>&1; echo \$? > ~/meera_jobs/$id/exit) > /dev/null 2>&1 &\necho started"
    }

    /** Starts a long command as a background job and returns its id at once. */
    private fun startJob(command: String, workdir: String?): String {
        val id = newJobId()
        Meera.scope.launch(Dispatchers.Main.immediate) { exec(jobCommand(id, command, workdir), null, 30) }
        return id
    }

    // ───────────── tools ─────────────

    suspend fun tool(name: String, args: JSONObject): ToolOut {
        val ctx = Meera.app
        if (name == "termux_check") return check()
        if (name == "termux_open_app") {
            val li = ctx.packageManager.getLaunchIntentForPackage(PKG)
                ?: return ToolOut("Termux is not installed (get it from F-Droid or GitHub).")
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try { ctx.startActivity(li); ToolOut("Termux opened.") } catch (e: Exception) { ToolOut("Could not open Termux: " + e.message) }
        }
        if (!Meera.settings.termuxEnabled) {
            return ToolOut("Termux control is OFF. Tell the user to switch it on in Settings -> Termux control (and do the one-time setup there). I did nothing.")
        }
        val workdir = args.optString("workdir").trim().ifBlank { null }
        return when (name) {
            "termux_run" -> {
                val command = args.optString("command").trim()
                if (command.isBlank()) return ToolOut("No command given.")
                val timeout = args.optInt("timeout_s", 60).coerceIn(3, 600)
                val risk = risky(command)
                if (risk != null) {
                    return Meera.confirmThen("Risky Termux command ($risk):\n$command\nShall I run it? (yes / no)") {
                        val id = startJob(command, workdir)
                        "Okay, started as job $id. Ask me for the status and I will read the result (termux_job_status)."
                    }
                }
                ToolOut(format(exec(command, workdir, timeout)))
            }
            "termux_job_start" -> {
                val command = args.optString("command").trim()
                if (command.isBlank()) return ToolOut("No command given.")
                val risk = risky(command)
                if (risk != null) {
                    return Meera.confirmThen("Risky Termux command ($risk):\n$command\nShall I run it as a background job? (yes / no)") {
                        "Okay, started as job " + startJob(command, workdir) + ". Ask me for the status and I will read the result."
                    }
                }
                ToolOut("Started as job " + startJob(command, workdir) + ". Check it with termux_job_status(id).")
            }
            "termux_job_status" -> {
                val id = args.optString("id").filter { it.isDigit() }
                if (id.isEmpty()) return ToolOut("Give the job id.")
                val cmd = "d=~/meera_jobs/$id; if [ -d \"\$d\" ]; then if [ -f \"\$d/exit\" ]; then echo \"DONE exit=\$(cat \$d/exit)\"; else echo RUNNING; fi; tail -n 40 \"\$d/out.log\"; else echo NO_SUCH_JOB; fi"
                val r = exec(cmd, null, 30)
                if (r.error != null || r.timedOut) return ToolOut(format(r))
                val txt = mask(r.stdout).trim()
                ToolOut(cut(txt.ifBlank { "No output." }))
            }
            "termux_job_stop" -> {
                val id = args.optString("id").filter { it.isDigit() }
                if (id.isEmpty()) return ToolOut("Give the job id.")
                val r = exec("pkill -f 'meera_job_$id'; echo stopped", null, 20)
                ToolOut(if (r.error != null) format(r) else "Job $id stopped.")
            }
            "termux_write_file" -> {
                val path = args.optString("path").trim()
                val content = args.optString("content")
                if (path.isBlank()) return ToolOut("No path given.")
                if (content.length > 40_000) return ToolOut("The content is too long (max 40000 characters).")
                val b64 = android.util.Base64.encodeToString(content.toByteArray(), android.util.Base64.NO_WRAP)
                val cmd = "mkdir -p \"\$(dirname " + shPath(path) + ")\" && printf %s " + sq(b64) + " | base64 -d > " + shPath(path) + " && echo written"
                if (sensitivePath(path)) {
                    return Meera.confirmThen("Write the file $path (outside the normal project area or a sensitive place)? (yes / no)") {
                        Meera.scope.launch(Dispatchers.Main.immediate) { exec(cmd, null, 30) }
                        "Okay, writing $path now. Check it with termux_read_file if needed."
                    }
                }
                val r = exec(cmd, null, 30)
                ToolOut(if (r.error != null || r.exit != 0) format(r) else "Written: $path (" + content.length + " characters).")
            }
            "termux_read_file" -> {
                val path = args.optString("path").trim()
                if (path.isBlank()) return ToolOut("No path given.")
                if (sensitivePath(path)) {
                    return Meera.confirmThen("Read the file $path (it may hold secrets)? (yes / no)") {
                        Meera.scope.launch(Dispatchers.Main.immediate) { exec("head -c 20000 " + shPath(path), null, 30) }
                        "Okay, reading $path now. Ask me again to show the content."
                    }
                }
                ToolOut(format(exec("head -c 20000 " + shPath(path), null, 30)))
            }
            "termux_list" -> {
                val path = args.optString("path").trim().ifBlank { "~" }
                ToolOut(format(exec("ls -la " + shPath(path), null, 30)))
            }
            "termux_install" -> {
                val pk = args.optString("packages").split(',', ' ').map { it.trim() }.filter { it.isNotEmpty() }
                if (pk.isEmpty() || pk.size > 10) return ToolOut("Give 1 to 10 package names.")
                if (pk.any { !Regex("[A-Za-z0-9+._-]+").matches(it) }) return ToolOut("A package name has odd characters. Refused.")
                ToolOut("Installing as job " + startJob("pkg install -y " + pk.joinToString(" "), null) + ". Check it with termux_job_status(id).")
            }
            else -> ToolOut("Unknown Termux tool: $name")
        }
    }

    /** Checks the three things that must be true: Termux installed, Android permission allowed, a test command works. */
    suspend fun check(): ToolOut {
        val ctx = Meera.app
        val inst = installed(ctx)
        val perm = hasPermission(ctx)
        val sb = StringBuilder()
        sb.append("Termux installed: ").append(if (inst) "yes" else "NO (get it from F-Droid or GitHub)").append('\n')
        sb.append("Android permission: ").append(if (perm) "allowed" else "NOT allowed").append('\n')
        sb.append("Switch in Settings: ").append(if (Meera.settings.termuxEnabled) "on" else "OFF").append('\n')
        if (inst && perm) {
            val r = exec("echo ok", null, 15)
            sb.append("Test command: ").append(
                when {
                    r.error != null -> "failed: " + r.error
                    r.timedOut -> "no answer (is allow-external-apps on? did you restart Termux?)"
                    r.stdout.trim() == "ok" -> "works"
                    else -> "unexpected answer: " + r.stdout.take(80)
                }
            )
        }
        return ToolOut(sb.toString().trim())
    }

    /** Checks used by task_verify: does a file exist (and contain the expected text)? */
    suspend fun fileCheck(path: String, expected: String): Pair<Boolean, String> {
        if (path.isBlank()) return Pair(false, "no path given")
        val cmd = if (expected.isBlank()) "test -e " + shPath(path) + " && echo YES || echo NO"
        else "test -e " + shPath(path) + " && grep -qiF " + sq(expected) + " " + shPath(path) + " && echo YES || echo NO"
        val r = exec(cmd, null, 20)
        if (r.error != null || r.timedOut) return Pair(false, r.error ?: "Termux did not answer")
        return Pair(r.stdout.trim().endsWith("YES"), if (r.stdout.trim().endsWith("YES")) "found" else "not found")
    }

    /** Emergency stop: stop waiting for results and kill the jobs that Meera started. */
    fun stopAll() {
        for ((_, d) in waiting) d.complete(null)
        waiting.clear()
        if (Meera.settings.termuxEnabled && installed(Meera.app) && hasPermission(Meera.app)) {
            Meera.scope.launch(Dispatchers.Main.immediate) { exec("pkill -f meera_job_; echo stopped", null, 15) }
        }
    }
}

/** Receives the result that Termux sends back through the PendingIntent. */
class TermuxResultReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("rid", -1)
        TermuxBridge.complete(id, intent.getBundleExtra("result"))
    }
}

/** The last commands Meera ran in Termux (kept on this phone only; the list can be cleared). */
object TermuxHistory {
    class Entry(val time: Long, val command: String, val exit: Int?, val out: String)

    val items = MutableStateFlow<List<Entry>>(emptyList())
    private const val KEY = "h"

    private fun prefs() = Meera.app.getSharedPreferences("meera_termux", Context.MODE_PRIVATE)

    fun load() {
        try {
            val a = JSONArray(prefs().getString(KEY, "[]"))
            val l = ArrayList<Entry>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                l.add(Entry(o.optLong("t"), o.optString("c"), if (o.has("e")) o.optInt("e") else null, o.optString("o")))
            }
            items.value = l
        } catch (e: Exception) { }
    }

    fun add(command: String, exit: Int?, out: String) {
        val e = Entry(System.currentTimeMillis(), TermuxBridge.mask(command).take(300), exit, TermuxBridge.mask(out).trim().take(200))
        val l = (listOf(e) + items.value).take(40)
        items.value = l
        try {
            val a = JSONArray()
            for (x in l) a.put(JSONObject().put("t", x.time).put("c", x.command).apply { if (x.exit != null) put("e", x.exit) }.put("o", x.out))
            prefs().edit().putString(KEY, a.toString()).apply()
        } catch (e2: Exception) { }
    }

    fun clear() {
        items.value = emptyList()
        prefs().edit().remove(KEY).apply()
    }
}

package com.meera.ai.ui.orb

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

// ───────────────────────── 0  Simple Orb ─────────────────────────
internal fun DrawScope.sSimple(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val base = 58f * (1f + lvl * 0.12f)
    if (!f.low) for (i in 4 downTo 0) {
        val r = base * (1.3f + i * 0.24f) * (1f + lvl * 0.3f)
        drawCircle(p.a.al((0.05f * (1f - i * 0.12f) + lvl * 0.04f) * f.glow), r, Offset.Zero)
    }
    if (f.speak || f.listen) for (i in 0..2) {
        val ph = ((t * 0.55f) + i / 3f) % 1f
        val r = if (f.speak) base * (1.05f + ph * 1.25f) else base * (2.2f - ph * 1.1f)
        val a = (1f - ph) * (if (f.speak) 0.18f + lvl * 0.5f else 0.3f)
        drawCircle(p.a.al(a), r, Offset.Zero, style = Stroke(2f))
    }
    val amp = if (f.speak) 16f * lvl + 2f else 3f
    val m = f.mem.path
    m.reset()
    for (i in 0..60) {
        val th = i / 60f * TAU
        val w = sin(3f * th + t * 2.4f) + 0.6f * sin(5f * th - t * 3.1f)
        val r = base * 1.14f * (1f + lvl * 0.18f) + amp * w * 0.6f
        if (i == 0) m.moveTo(cos(th) * r, sin(th) * r) else m.lineTo(cos(th) * r, sin(th) * r)
    }
    m.close()
    drawPath(m, p.a.mixW(0.2f).al(0.7f), style = Stroke(2f))
    val r0 = base * (1f + lvl * 0.2f)
    drawCircle(
        Brush.radialGradient(listOf(p.a.mixW(0.75f), p.a, p.a.dk(0.5f)), center = Offset(-r0 * 0.32f, -r0 * 0.38f), radius = r0 * 1.6f),
        r0, Offset.Zero
    )
    rotate(-28.6f, Offset(-r0 * 0.3f, -r0 * 0.42f)) {
        drawOval(Color.White.copy(alpha = 0.22f), Offset(-r0 * 0.64f, -r0 * 0.58f), Size(r0 * 0.68f, r0 * 0.32f))
    }
}

// ───────────────────────── 1  Plasma Orb ─────────────────────────
internal fun DrawScope.sPlasma(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val mem = f.mem
    glow(f, 0f, 0f, 175f, p.a, 0.2f + lvl * 0.22f)
    glow(f, 0f, 20f, 120f, p.b, 0.1f + lvl * 0.12f)
    val r = 54f * (1f + lvl * 0.16f + (if (f.idle) 0.035f * sin(1.4f * t) else 0f))
    val n = if (f.low) 36 else 72
    val k = 72f / n
    val r0 = r * 1.3f
    for (i in 0 until n) {
        val th = i.toFloat() / n * TAU - 1.5708f
        val mm = abs(i - n / 2f) / (n / 2f)
        val len = when {
            f.speak -> 2.5f + lvl * 34f * (0.35f + 0.65f * abs(sin(i * k * 0.83f + t * 6.2f) * sin(i * k * 0.31f - t * 2.7f))) * (1f - 0.3f * mm)
            f.think -> 2.5f + 16f * max(0f, cos(th - t * 2.6f)).pow(6)
            f.listen -> 2.5f + lvl * 20f * (0.5f + 0.5f * sin(i * k * 0.5f + t * 3f))
            else -> 2.5f + 1.2f * sin(i * k * 0.4f + t * 1.1f)
        }
        val col = lerp(p.a, p.b, abs(i.toFloat() / n * 2f - 1f))
        drawLine(
            col.mixW(0.15f).al(0.35f + min(0.55f, len / 40f)),
            Offset(cos(th) * r0, sin(th) * r0), Offset(cos(th) * (r0 + len), sin(th) * (r0 + len)), 2.4f, StrokeCap.Round
        )
    }
    if (f.speak || f.listen) for (i in 0..2) {
        val ph = ((t * 0.5f) + i / 3f) % 1f
        val rr = if (f.speak) r * (1.6f + ph * 1.4f) else r * (3f - ph * 1.4f)
        val a = (1f - ph) * (if (f.speak) 0.1f + lvl * 0.4f else 0.22f)
        drawCircle(p.b.al(a), rr, Offset.Zero, style = Stroke(1.6f))
    }
    for (k2 in 0..1) {
        val ra = t * 0.18f * (if (k2 == 1) -1f else 1f) + k2 * 1.1f
        val rr = r * 2.15f
        rotate(ra * RAD2DEG, Offset.Zero) {
            drawOval(p.b.al(0.13f), Offset(-rr, -rr * 0.36f), Size(rr * 2f, rr * 0.72f), style = Stroke(1f))
        }
        val ph = t * (0.9f + k2 * 0.35f) + k2 * 2f
        val x0 = cos(ph) * rr
        val y0 = sin(ph) * rr * 0.36f
        val px = x0 * cos(ra) - y0 * sin(ra)
        val py = x0 * sin(ra) + y0 * cos(ra)
        glow(f, px, py, 10f, p.b.mixW(0.4f), 0.7f)
        drawCircle(p.b.mixW(0.85f).al(0.95f), 2.2f, Offset(px, py))
    }
    val ns = if (f.low) 20 else 46
    for (i in 0 until ns) {
        val h1 = hash01(i * 1.7f)
        val h2 = hash01(i * 3.1f)
        val h3 = hash01(i * 5.9f)
        val an = h1 * TAU + t * (0.08f + h2 * 0.25f) * (0.4f + lvl * 2.2f)
        val rr = 92f + h3 * 78f
        val tw = 0.5f + 0.5f * sin(t * 1.5f + h2 * 6f)
        drawCircle(p.b.mixW(0.6f).al(0.25f + 0.35f * tw), 0.6f + h3 * 1.4f, Offset(cos(an) * rr, sin(an) * rr * 0.92f))
    }
    if (f.think) {
        val a0 = t * 2.4f
        for (j in 0 until 16) {
            val st = (a0 - j * 0.06f - 0.06f) * RAD2DEG
            drawArc(
                p.b.mixW(0.5f).al((1f - j / 16f) * 0.9f), st, 0.06f * RAD2DEG + 0.5f, false,
                Offset(-r * 1.62f, -r * 1.62f), Size(r * 3.24f, r * 3.24f), style = Stroke(3.6f)
            )
        }
    }
    val amp = r * (if (f.speak) 0.03f + lvl * 0.14f else if (f.think) 0.05f else 0.025f)
    val sp = if (f.think) 2.2f else 1f
    val body = mem.path
    blobPath(body, r, amp, t, sp)
    drawPath(body, Brush.radialGradient(listOf(p.a.mixW(0.6f), p.a, p.a.dk(0.3f)), center = Offset(-r * 0.3f, -r * 0.4f), radius = r * 1.5f))
    clipPath(body) {
        for (i in 0..2) {
            val bx = cos(t * 0.7f + i * 2.1f) * r * 0.5f
            val by = sin(t * 0.9f + i * 2.1f) * r * 0.5f
            val col = when (i) { 0 -> p.b; 1 -> p.a.mixW(0.5f); else -> p.b.mixW(0.5f) }
            soft(f, bx, by, r * 0.95f, col, 0.5f - i * 0.1f + lvl * 0.25f)
        }
        drawCircle(
            Brush.radialGradient(
                0f to p.b.mixW(0.6f).al(0f), 0.62f to p.b.mixW(0.6f).al(0f), 1f to p.b.mixW(0.6f).al(0.5f),
                center = Offset.Zero, radius = r * 1.02f
            ), r * 1.05f, Offset.Zero
        )
        glow(f, 0f, r * 0.85f, r * 0.9f, p.b.mixW(0.5f), 0.35f)
    }
    drawArc(p.b.mixW(0.7f).al(0.45f), 27f, 126f, false, Offset(-r * 0.985f, -r * 0.985f), Size(r * 1.97f, r * 1.97f), style = Stroke(1.4f))
    rotate(-31.5f, Offset(-r * 0.32f, -r * 0.46f)) {
        drawOval(Color.White.copy(alpha = 0.26f), Offset(-r * 0.68f, -r * 0.6f), Size(r * 0.72f, r * 0.28f))
    }
    drawCircle(Color.White.copy(alpha = 0.8f), r * 0.05f, Offset(-r * 0.46f, -r * 0.52f))
    glow(f, 0f, 0f, r * 2.2f, p.b.mixW(0.3f), 0.1f + lvl * 0.2f)
}

// ───────────────────────── 2  Hacker HUD ─────────────────────────
private val RAIN_CHARS = "01ABCDEF{}[]#\$%&=+<>".toCharArray()
private val hackPaint = Paint().apply {
    isAntiAlias = true
    typeface = Typeface.MONOSPACE
    textSize = 11f
}

internal fun DrawScope.sHacker(f: OrbFrame) {
    val c = f.hack
    val lvl = f.lvl
    val t = f.t
    val mem = f.mem
    drawRect(Color.Black, Offset(-170f, -170f), Size(340f, 340f))
    val nat = drawContext.canvas.nativeCanvas
    val rs = 1f + lvl * 1.6f + (if (f.think) 1.2f else 0f)
    val step = if (f.low) 2 else 1
    var ci = 0
    while (ci < 31) {
        val x = -165f + ci * 11f
        mem.rainY[ci] = mem.rainY[ci] + mem.rainSp[ci] * rs
        if (mem.rainY[ci] > 44f) mem.rainY[ci] = -hash01(ci + t) * 10f
        val head = mem.rainY[ci].toInt()
        for (j in 0 until 9) {
            val row = head - j
            if (row < 0 || row > 31) continue
            val a = (1f - j / 9f) * 0.6f
            val col = if (j == 0) Color.White else c
            hackPaint.color = col.al(a).toArgb()
            val idx = (hash01(ci * 7.1f + row * 3.3f + (mem.frame / 6) * 0.7f) * RAIN_CHARS.size).toInt().coerceIn(0, RAIN_CHARS.size - 1)
            nat.drawText(RAIN_CHARS, idx, 1, x, -170f + row * 11f, hackPaint)
        }
        ci += step
    }
    drawCircle(
        Brush.radialGradient(listOf(Color.Black.copy(alpha = 0.92f), Color.Black.copy(alpha = 0.75f), Color.Transparent), center = Offset.Zero, radius = 128f),
        128f, Offset.Zero
    )
    val r = 54f * (1f + lvl * 0.12f)
    glow(f, 0f, 0f, r * 2.4f, c, 0.1f + lvl * 0.18f)
    val rt = r * 1.75f
    for (i in 0 until 120) {
        val a = i / 120f * TAU + f.rot * 0.4f
        val lg = i % 5 == 0
        val ln = if (lg) 7f else 3f
        drawLine(c.al(if (lg) 0.7f else 0.35f), Offset(cos(a) * rt, sin(a) * rt), Offset(cos(a) * (rt + ln), sin(a) * (rt + ln)), 1f)
    }
    val r2 = r * 1.98f - (if (f.listen) lvl * 14f else 0f)
    for (i in 0 until 6) {
        val a0 = (-f.rot * 0.7f + i * 1.0472f) * RAD2DEG
        drawArc(c.al(0.8f), a0, 0.62f * RAD2DEG, false, Offset(-r2, -r2), Size(r2 * 2f, r2 * 2f), style = Stroke(2.6f))
    }
    drawCircle(c.al(0.18f), r * 2.2f, Offset.Zero, style = Stroke(1f))
    for (i in 0 until 3) {
        val a0 = (f.rot * 1.8f + i * 2.094f) * RAD2DEG
        drawArc(c.mixW(0.4f).al(0.95f), a0, 0.18f * RAD2DEG, false, Offset(-r * 2.2f, -r * 2.2f), Size(r * 4.4f, r * 4.4f), style = Stroke(3f))
    }
    val rw = r * 1.3f
    val wave = mem.path
    fun buildWave(ox: Float) {
        wave.reset()
        val pts = if (f.low) 90 else 180
        for (i in 0..pts) {
            val th = i.toFloat() / pts * TAU
            val d = when {
                f.speak -> lvl * 20f * (sin(th * 7f + t * 12f) * 0.5f + sin(th * 13f - t * 8f) * 0.3f + sin(th * 3f + t * 5f) * 0.2f)
                f.listen -> lvl * 10f * sin(th * 5f + t * 4f)
                f.think -> 4f * sin(th * 12f + t * 10f) * (0.5f + 0.5f * sin(t * 3f))
                else -> 1.2f * sin(th * 6f + t)
            }
            val rr = rw + d
            if (i == 0) wave.moveTo(ox + cos(th) * rr, sin(th) * rr) else wave.lineTo(ox + cos(th) * rr, sin(th) * rr)
        }
        wave.close()
    }
    if (lvl > 0.3f) {
        val gl = lvl * 3f
        buildWave(-gl)
        drawPath(wave, Color(1f, 0.16f, 0.31f, 0.5f), style = Stroke(1.4f), blendMode = BlendMode.Plus)
        buildWave(gl)
        drawPath(wave, Color(0f, 0.78f, 1f, 0.5f), style = Stroke(1.4f), blendMode = BlendMode.Plus)
    }
    buildWave(0f)
    drawPath(wave, c.mixW(0.2f).al(0.95f), style = Stroke(1.6f))
    // point-cloud sphere with a wireframe
    val tp = mem.tmp110
    val sph = mem.sphere110
    for (i in sph.indices) {
        val q = sph[i]
        val d = when {
            f.speak -> lvl * 0.6f * abs(sin(i * 1.7f + t * 9f) * sin(i * 0.37f - t * 4f))
            f.listen -> lvl * 0.15f
            f.think -> 0.05f * sin(i + t * 6f)
            else -> 0f
        }
        rotYX(q[0], q[1], q[2], f.rot, 0.35f, tp, i * 3)
        val rp = r * (1f + d)
        tp[i * 3] = tp[i * 3] * rp
        tp[i * 3 + 1] = tp[i * 3 + 1] * rp
        tp[i * 3 + 2] = (tp[i * 3 + 2] + 1f) / 2f
    }
    if (!f.low) for (pr in mem.nearPairs) {
        val a = pr[0] * 3
        val b = pr[1] * 3
        drawLine(c.al(0.05f + 0.22f * (tp[a + 2] + tp[b + 2]) / 2f), Offset(tp[a], tp[a + 1]), Offset(tp[b], tp[b + 1]), 0.8f)
    }
    for (i in sph.indices) {
        val z = tp[i * 3 + 2]
        val s = 1f + 1.6f * z
        drawRect(c.mixW(z * 0.6f).al(0.3f + 0.7f * z), Offset(tp[i * 3] - s / 2f, tp[i * 3 + 1] - s / 2f), Size(s, s))
    }
    // corners + terminal text
    val m = 8f - 170f
    val l = 14f
    val cc = c.al(0.85f)
    val sw = 1.5f
    drawLine(cc, Offset(m, m + l), Offset(m, m), sw); drawLine(cc, Offset(m, m), Offset(m + l, m), sw)
    drawLine(cc, Offset(-m - l, m), Offset(-m, m), sw); drawLine(cc, Offset(-m, m), Offset(-m, m + l), sw)
    drawLine(cc, Offset(m, -m - l), Offset(m, -m), sw); drawLine(cc, Offset(m, -m), Offset(m + l, -m), sw)
    drawLine(cc, Offset(-m - l, -m), Offset(-m, -m), sw); drawLine(cc, Offset(-m, -m), Offset(-m, -m + (-l)), sw)
    if (mem.frame % (if (f.think) 4 else if (f.speak) 8 else 40) == 0) {
        mem.hex = "0x" + (hash01(mem.frame * 0.37f) * 65535f).toInt().toString(16).uppercase().padStart(4, '0')
    }
    hackPaint.color = c.al(0.85f).toArgb()
    hackPaint.textAlign = Paint.Align.LEFT
    nat.drawText("MEERA://VOICE", -154f, -142f, hackPaint)
    nat.drawText("LINK: SECURE", -154f, 152f, hackPaint)
    hackPaint.textAlign = Paint.Align.RIGHT
    nat.drawText("LVL " + ((lvl * 100f).toInt() / 100f).toString(), 154f, -142f, hackPaint)
    nat.drawText(mem.hex, 154f, 152f, hackPaint)
    hackPaint.textAlign = Paint.Align.LEFT
    val lit = (min(1f, lvl / 0.8f) * 16f).toInt()
    for (i in 0 until 16) drawRect(c.al(if (i < lit) 0.9f else 0.15f), Offset(-63f + i * 8f, 144f), Size(6f, 7f))
    if (!f.low) {
        var y = -170f
        while (y < 170f) { drawRect(Color.Black.copy(alpha = 0.28f), Offset(-170f, y), Size(340f, 1f)); y += 3f }
    }
    val by = (t * 70f) % 380f - 190f
    drawRect(c.al(0.07f), Offset(-170f, by), Size(340f, 22f))
}

// ───────────────────────── 3  Liquid Aura ─────────────────────────
internal fun DrawScope.sLiquid(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val r = 66f * (1f + lvl * 0.14f + (if (f.idle) 0.03f * sin(1.3f * t) else 0f))
    val amp = r * (0.04f + lvl * (if (f.speak) 0.2f else 0.08f))
    val sp = if (f.think) 2.4f else 1f
    glow(f, 0f, 0f, r * 2.5f, p.a, 0.14f + lvl * 0.2f)
    glow(f, 10f, 14f, r * 1.9f, p.b, 0.1f + lvl * 0.12f)
    if (!f.low) drawOval(p.b.al(((0.1f + lvl * 0.1f) * f.glow)), Offset(-r * 0.9f, r * 1.55f - r * 0.12f), Size(r * 1.8f, r * 0.24f), blendMode = BlendMode.Plus)
    val body = f.mem.path
    blobPath(body, r, amp, t, sp)
    drawPath(body, p.a.dk(0.22f))
    clipPath(body) {
        val cl = arrayOf(p.a, p.b, p.c, p.a.mixW(0.5f), p.b.mixW(0.4f))
        for (i in 0..4) {
            val bx = cos(t * (0.5f + i * 0.17f) + i * 1.7f) * r * 0.55f
            val by = sin(t * (0.6f + i * 0.13f) + i * 2.3f) * r * 0.55f
            soft(f, bx, by, r * (0.9f + lvl * 0.4f), cl[i], 0.6f)
        }
    }
    drawPath(body, p.b.al(0.12f), style = Stroke(9f))
    var px = 0f
    var py = 0f
    val steps = 72
    for (i in 0..steps) {
        val th = i.toFloat() / steps * TAU
        val rr = blobR(th, r, amp, t, sp)
        val x = cos(th) * rr
        val y = sin(th) * rr
        if (i > 0) {
            val k = 0.5f + 0.5f * cos(th - f.rot * 1.2f)
            drawLine(lerp(p.a, p.b.mixW(0.7f), k).al(0.15f + 0.8f * k), Offset(px, py), Offset(x, y), 2.6f, StrokeCap.Round)
        }
        px = x
        py = y
    }
    rotate(-28.6f, Offset(-r * 0.3f, -r * 0.5f)) {
        drawOval(Color.White.copy(alpha = 0.16f), Offset(-r * 0.75f, -r * 0.66f), Size(r * 0.9f, r * 0.32f))
    }
}

// ───────────────────────── 4  Halo Ring ─────────────────────────
internal fun DrawScope.sHalo(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val r0 = 70f * (if (f.listen) 1f - lvl * 0.05f else 1f)
    val seg = if (f.low) 70 else 140
    glow(f, 0f, 0f, 150f, p.a, 0.08f + lvl * 0.12f)
    val lw = 6f + lvl * (if (f.speak) 16f else 6f)
    val sweep = 1.3f * 360f / seg
    for (i in 0 until seg) {
        val a0 = i.toFloat() / seg * TAU
        val col = p.tri(i.toFloat() / seg + f.rot * 0.08f)
        val br = if (f.think) 0.3f + 0.7f * max(0f, cos(a0 - f.rot * 3f)).pow(3) else 0.95f
        val r = r0 + if (f.speak) lvl * 12f * sin(a0 * 5f + t * 9f) * sin(a0 * 2f - t * 3f) else 1.5f * sin(a0 * 4f + t)
        val tl = Offset(-r, -r)
        val sz = Size(2f * r, 2f * r)
        if (!f.low) drawArc(col.al(0.1f * br * f.glow), a0 * RAD2DEG, sweep, false, tl, sz, style = Stroke(lw * 3f), blendMode = BlendMode.Plus)
        drawArc(col.mixW(0.15f).al(br * 0.95f), a0 * RAD2DEG, sweep, false, tl, sz, style = Stroke(lw))
    }
    drawCircle(Color.White.copy(alpha = 0.22f), r0 * 0.72f, Offset.Zero, style = Stroke(1f))
    val nd = if (f.low) 12 else 24
    for (i in 0 until nd) {
        val a = i.toFloat() / nd * TAU + f.rot * 0.3f
        val tw = 0.5f + 0.5f * sin(t * 2f + i)
        drawCircle(Color.White.copy(alpha = 0.15f + 0.4f * tw), 1.3f, Offset(cos(a) * r0 * 0.55f, sin(a) * r0 * 0.55f))
    }
    glow(f, 0f, 0f, 14f + lvl * 34f, Color.White, 0.5f)
    drawCircle(Color.White.copy(alpha = 0.95f), 3f + lvl * 6f, Offset.Zero)
}

// ───────────────────────── 5  Aurora Waves ─────────────────────────
private val WV_F = floatArrayOf(2.2f, 3.1f, 4.3f, 5.6f)
private val WV_S = floatArrayOf(1.4f, -1.9f, 2.4f, -3.1f)
private val WV_P = floatArrayOf(0f, 1.3f, 2.6f, 3.9f)
private val WV_K = floatArrayOf(1f, 0.8f, 0.6f, 0.4f)

internal fun DrawScope.sWaves(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    glow(f, 0f, 0f, 150f, p.b, 0.07f + lvl * 0.1f)
    val w = 300f
    val x0 = -w / 2f
    val amp = if (f.speak) 70f * lvl * 1.2f else if (f.listen) 18f + lvl * 40f else if (f.think) 10f else 5f
    val tm = if (f.think) 2f else 1f
    val cols = arrayOf(p.a, p.b, p.c, p.b.mixW(0.6f))
    val ys = FloatArray(101)
    val fill = f.mem.path
    val top = f.mem.path2
    for (k in 0..3) {
        for (i in 0..100) {
            val u = i / 100f
            val env = sin(u * PIF).pow(2)
            ys[i] = env * amp * WV_K[k] * sin(u * PIF * WV_F[k] + t * WV_S[k] * tm + WV_P[k])
        }
        fill.reset()
        top.reset()
        for (i in 0..100) {
            val x = x0 + i / 100f * w
            if (i == 0) { fill.moveTo(x, -ys[i]); top.moveTo(x, -ys[i]) } else { fill.lineTo(x, -ys[i]); top.lineTo(x, -ys[i]) }
        }
        for (i in 100 downTo 0) fill.lineTo(x0 + i / 100f * w, ys[i])
        fill.close()
        drawPath(fill, cols[k].al(0.22f), blendMode = BlendMode.Plus)
        drawPath(top, cols[k].mixW(0.4f).al(0.85f), style = Stroke(1.6f))
    }
    drawLine(Color.White.copy(alpha = 0.28f), Offset(x0, 0f), Offset(x0 + w, 0f), 1f)
    if (f.think) glow(f, x0 + ((t * 0.5f) % 1f) * w, 0f, 16f, Color.White, 0.8f)
}

// ───────────────────────── 6  Gold Luxe ─────────────────────────
internal fun DrawScope.sGold(f: OrbFrame) {
    val l = f.pal.l
    val lvl = f.lvl
    val t = f.t
    glow(f, 0f, 0f, 140f, l, 0.06f + lvl * 0.14f)
    for (i in 0 until 60) {
        val a = i / 60f * TAU - 1.5708f
        val lg = i % 5 == 0
        val ln = if (lg) 10f else 5f
        drawLine(l.al(if (lg) 0.85f else 0.4f), Offset(cos(a) * 122f, sin(a) * 122f), Offset(cos(a) * (122f + ln), sin(a) * (122f + ln)), if (lg) 1.6f else 1f)
    }
    val rads = floatArrayOf(40f, 62f, 84f, 104f)
    for (k in 0..3) {
        val r = rads[k] * (1f + lvl * 0.05f * (k + 1) * (if (f.speak) 1f else 0.4f))
        drawCircle(l.al(0.25f + 0.1f * k), r, Offset.Zero, style = Stroke(1f))
    }
    for (j in 0..3) {
        val a0 = (f.rot * 0.6f + j * 1.5708f) * RAD2DEG
        drawArc(l.mixW(0.3f).al(0.85f), a0, 0.7f * RAD2DEG, false, Offset(-84f, -84f), Size(168f, 168f), style = Stroke(2.2f))
    }
    for (j in 0..2) {
        val a0 = (-f.rot * 0.9f + j * 2.094f) * RAD2DEG
        drawArc(l.mixW(0.3f).al(0.85f), a0, 0.5f * RAD2DEG, false, Offset(-62f, -62f), Size(124f, 124f), style = Stroke(2.2f))
    }
    if (f.speak) for (i in 0..2) {
        val ph = ((t * 0.55f) + i / 3f) % 1f
        drawCircle(l.al((1f - ph) * (0.1f + lvl * 0.4f)), 30f + ph * 90f, Offset.Zero, style = Stroke(1.2f))
    }
    val gs = 24f * (1f + lvl * 0.35f)
    val hex = f.mem.path
    hex.reset()
    for (i in 0..5) {
        val a = f.rot * 0.5f + i * 1.0472f
        if (i == 0) hex.moveTo(cos(a) * gs, sin(a) * gs) else hex.lineTo(cos(a) * gs, sin(a) * gs)
    }
    hex.close()
    drawPath(hex, l.mixW(0.4f).al(0.95f), style = Stroke(1.6f))
    for (i in 0..5) {
        val a = f.rot * 0.5f + i * 1.0472f
        drawLine(l.al(0.35f), Offset.Zero, Offset(cos(a) * gs, sin(a) * gs), 1f)
    }
    val hex2 = f.mem.path2
    hex2.reset()
    for (i in 0..5) {
        val a = -f.rot * 0.8f + i * 1.0472f
        if (i == 0) hex2.moveTo(cos(a) * gs * 0.5f, sin(a) * gs * 0.5f) else hex2.lineTo(cos(a) * gs * 0.5f, sin(a) * gs * 0.5f)
    }
    hex2.close()
    drawPath(hex2, l.al(0.15f + lvl * 0.4f))
    glow(f, 0f, 0f, 30f + lvl * 40f, l.mixW(0.5f), 0.35f + lvl * 0.3f)
    for (i in 0 until 14) {
        val an = i * 0.449f + f.rot * (0.3f + (i % 3) * 0.1f)
        val rr = 44f + ((i * 37) % 64)
        val tw = 0.5f + 0.5f * sin(t * (1.5f + i % 4) + i)
        sparkle(f, cos(an) * rr, sin(an) * rr, 2f + 3f * tw + lvl * 3f, l.mixW(0.5f), 0.3f + 0.6f * tw)
    }
}

// ───────────────────────── 7  Nebula ─────────────────────────
internal fun DrawScope.sNebula(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    soft(f, 0f, 0f, 60f + lvl * 70f, p.a.mixW(0.3f), 0.28f + lvl * 0.2f)
    val n = if (f.low) 130 else 260
    for (i in 0 until n) {
        val h1 = hash01(i * 1.7f)
        val h2 = hash01(i * 3.1f)
        val h3 = hash01(i * 5.3f)
        val h4 = hash01(i * 7.9f)
        val rad = 8f + h1.pow(0.8f) * 108f
        val a0 = (i % 2) * PIF + rad * 0.05f + (h2 - 0.5f) * 0.6f
        val w = 1f / sqrt(rad / 20f + 0.3f)
        val a = a0 + f.rot * w * 1.3f
        var r = rad * (1f + (if (f.speak) lvl * 0.4f * abs(sin(h4 * TAU + t * 8f)) else lvl * 0.1f))
        if (f.think) r *= 0.85f + 0.1f * sin(t * 3f + h4 * TAU)
        if (f.listen) r *= 0.9f + lvl * 0.2f
        val x = cos(a) * r
        val y = sin(a) * r * 0.7f
        val col = if (h3 > 0.85f) p.c else lerp(p.a, p.b, rad / 116f)
        val tw = 0.5f + 0.5f * sin(t * 2f + h4 * TAU)
        val sz = 1f + h3 * 1.7f
        drawRect(col.mixW(0.2f).al(0.35f + 0.5f * tw), Offset(x - sz / 2f, y - sz / 2f), Size(sz, sz), blendMode = BlendMode.Plus)
    }
    soft(f, 0f, 0f, 26f, Color.White, 0.55f + lvl * 0.3f)
    drawOval(p.b.al(0.1f), Offset(-124f, -87f), Size(248f, 174f), style = Stroke(1f))
}

// ───────────────────────── 8  Crystal Prism ─────────────────────────
private val ICO_V: Array<FloatArray> = run {
    val ph = (1f + sqrt(5f)) / 2f
    val raw = arrayOf(
        floatArrayOf(-1f, ph, 0f), floatArrayOf(1f, ph, 0f), floatArrayOf(-1f, -ph, 0f), floatArrayOf(1f, -ph, 0f),
        floatArrayOf(0f, -1f, ph), floatArrayOf(0f, 1f, ph), floatArrayOf(0f, -1f, -ph), floatArrayOf(0f, 1f, -ph),
        floatArrayOf(ph, 0f, -1f), floatArrayOf(ph, 0f, 1f), floatArrayOf(-ph, 0f, -1f), floatArrayOf(-ph, 0f, 1f)
    )
    Array(12) { i ->
        val l = sqrt(raw[i][0] * raw[i][0] + raw[i][1] * raw[i][1] + raw[i][2] * raw[i][2])
        floatArrayOf(raw[i][0] / l, raw[i][1] / l, raw[i][2] / l)
    }
}
private val ICO_F = arrayOf(
    intArrayOf(0, 11, 5), intArrayOf(0, 5, 1), intArrayOf(0, 1, 7), intArrayOf(0, 7, 10), intArrayOf(0, 10, 11),
    intArrayOf(1, 5, 9), intArrayOf(5, 11, 4), intArrayOf(11, 10, 2), intArrayOf(10, 7, 6), intArrayOf(7, 1, 8),
    intArrayOf(3, 9, 4), intArrayOf(3, 4, 2), intArrayOf(3, 2, 6), intArrayOf(3, 6, 8), intArrayOf(3, 8, 9),
    intArrayOf(4, 9, 5), intArrayOf(2, 4, 11), intArrayOf(6, 2, 10), intArrayOf(8, 6, 7), intArrayOf(9, 8, 1)
)

internal fun DrawScope.sCrystal(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val r = 70f
    glow(f, 0f, 0f, 150f, p.a, 0.12f + lvl * 0.18f)
    glow(f, 0f, 0f, 90f, p.b, 0.1f + lvl * 0.1f)
    val vs = FloatArray(36)
    for (i in 0 until 12) {
        val v = ICO_V[i]
        rotYX(v[0], v[1], v[2], f.rot, f.rot * 0.6f + 0.4f, vs, i * 3)
        val s = r * (1f + (if (f.speak) lvl * 0.5f * abs(sin(i * 2.1f + t * 9f)) else lvl * 0.1f))
        vs[i * 3] *= s; vs[i * 3 + 1] *= s; vs[i * 3 + 2] *= s
    }
    val zs = FloatArray(20)
    val lt = FloatArray(20)
    for (fi in 0 until 20) {
        val fc = ICO_F[fi]
        val ax = vs[fc[0] * 3]; val ay = vs[fc[0] * 3 + 1]; val az = vs[fc[0] * 3 + 2]
        val ux = vs[fc[1] * 3] - ax; val uy = vs[fc[1] * 3 + 1] - ay; val uz = vs[fc[1] * 3 + 2] - az
        val wx = vs[fc[2] * 3] - ax; val wy = vs[fc[2] * 3 + 1] - ay; val wz = vs[fc[2] * 3 + 2] - az
        var nx = uy * wz - uz * wy
        var ny = uz * wx - ux * wz
        var nz = ux * wy - uy * wx
        val l = sqrt(nx * nx + ny * ny + nz * nz).let { if (it < 0.0001f) 1f else it }
        nx /= l; ny /= l; nz /= l
        lt[fi] = abs(nx * -0.4f + ny * -0.6f + nz * 0.7f)
        zs[fi] = (az + vs[fc[1] * 3 + 2] + vs[fc[2] * 3 + 2]) / 3f
    }
    val order = IntArray(20) { it }
    for (i in 1 until 20) {
        val key = order[i]
        var j = i - 1
        while (j >= 0 && zs[order[j]] > zs[key]) { order[j + 1] = order[j]; j-- }
        order[j + 1] = key
    }
    val tri = f.mem.path
    for (oi in 0 until 20) {
        val fi = order[oi]
        val fc = ICO_F[fi]
        tri.reset()
        for (k in 0..2) {
            val z = vs[fc[k] * 3 + 2]
            val kk = 300f / (300f - z)
            val x = vs[fc[k] * 3] * kk
            val y = vs[fc[k] * 3 + 1] * kk
            if (k == 0) tri.moveTo(x, y) else tri.lineTo(x, y)
        }
        tri.close()
        val col = p.tri(fi / 20f + t * 0.05f)
        drawPath(tri, col.al(0.2f + 0.35f * lt[fi] + lvl * 0.1f))
        drawPath(tri, Color.White.copy(alpha = 0.25f + 0.35f * lt[fi]), style = Stroke(1f))
    }
    val v2 = FloatArray(36)
    for (i in 0 until 12) {
        val v = ICO_V[i]
        rotYX(v[0], v[1], v[2], -f.rot * 1.3f, f.rot * 0.4f, v2, i * 3)
        v2[i * 3] *= r * 0.42f; v2[i * 3 + 1] *= r * 0.42f
    }
    for (fi in 0 until 20) {
        val fc = ICO_F[fi]
        tri.reset()
        tri.moveTo(v2[fc[0] * 3], v2[fc[0] * 3 + 1])
        tri.lineTo(v2[fc[1] * 3], v2[fc[1] * 3 + 1])
        tri.lineTo(v2[fc[2] * 3], v2[fc[2] * 3 + 1])
        tri.close()
        drawPath(tri, p.b.mixW(0.5f).al(0.4f), style = Stroke(1f))
    }
    glow(f, 0f, 0f, 20f + lvl * 34f, Color.White, 0.45f)
}

// ───────────────────────── 9  Sonar ─────────────────────────
private val BLIP_A = floatArrayOf(0.5f, 1.9f, 3.1f, 4.2f, 5f, 5.8f)
private val BLIP_R = floatArrayOf(60f, 95f, 40f, 110f, 75f, 100f)

internal fun DrawScope.sSonar(f: OrbFrame) {
    val p = f.pal
    val lvl = f.lvl
    val t = f.t
    val m = f.mem
    glow(f, 0f, 0f, 150f, p.a, 0.08f + lvl * 0.1f)
    for (r in floatArrayOf(40f, 80f, 120f)) drawCircle(Color.White.copy(alpha = 0.12f), r, Offset.Zero, style = Stroke(1f))
    drawLine(Color.White.copy(alpha = 0.12f), Offset(-130f, 0f), Offset(130f, 0f), 1f)
    drawLine(Color.White.copy(alpha = 0.12f), Offset(0f, -130f), Offset(0f, 130f), 1f)
    val iv = if (f.speak) 0.3f else if (f.listen) 1.2f else if (f.idle) 2.8f else 999f
    if (t - m.lastEmit > iv) {
        if (m.rippleN < 12) { m.rippleT[m.rippleN] = t; m.rippleS[m.rippleN] = 0.3f + lvl; m.rippleN++ }
        m.lastEmit = t
    }
    var w = 0
    for (i in 0 until m.rippleN) {
        if (t - m.rippleT[i] < 2.6f) { m.rippleT[w] = m.rippleT[i]; m.rippleS[w] = m.rippleS[i]; w++ }
    }
    m.rippleN = w
    for (i in 0 until m.rippleN) {
        val age = (t - m.rippleT[i]) / 2.6f
        val rad = if (f.listen) 150f - age * 136f else 14f + age * 140f
        val s = min(1f, m.rippleS[i])
        drawCircle(p.tri(age).al((1f - age).pow(1.5f) * (0.25f + 0.6f * s)), rad, Offset.Zero, style = Stroke(1f + (1f - age) * 3f * s), blendMode = BlendMode.Plus)
    }
    val sa = f.rot * 2.2f
    rotate(sa * RAD2DEG, Offset.Zero) {
        drawCircle(
            Brush.sweepGradient(
                0f to p.b.al(0f), 0.9f to p.b.al(0f), 1f to p.b.al(if (f.think) 0.55f else 0.2f),
                center = Offset.Zero
            ), 128f, Offset.Zero
        )
    }
    drawLine(p.b.mixW(0.4f).al(if (f.think) 0.85f else 0.3f), Offset.Zero, Offset(cos(sa) * 128f, sin(sa) * 128f), 1.4f)
    for (i in 0..5) {
        val behind = ((sa - BLIP_A[i]) % TAU + TAU) % TAU
        val al = max(0f, 1f - behind / 3.5f) * (if (f.think) 1f else 0.5f)
        if (al > 0.02f) glow(f, cos(BLIP_A[i]) * BLIP_R[i], sin(BLIP_A[i]) * BLIP_R[i], 9f, p.c.mixW(0.3f), al * 0.9f)
    }
    glow(f, 0f, 0f, 10f + lvl * 26f, Color.White, 0.6f)
    drawCircle(Color.White.copy(alpha = 0.95f), 3f + lvl * 5f, Offset.Zero)
}

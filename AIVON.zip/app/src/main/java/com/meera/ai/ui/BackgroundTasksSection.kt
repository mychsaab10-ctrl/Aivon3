package com.meera.ai.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meera.ai.Meera
import com.meera.ai.automation.MeeraAccessibilityService
import com.meera.ai.tasks.TStatus
import com.meera.ai.tasks.TaskManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Settings -> Background tasks: switch, floating window mode and size, accessibility status, demo, history. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackgroundTasksSection() {
    val ctx = LocalContext.current
    val s = Meera.settings
    var on by remember { mutableStateOf(s.tasksEnabled) }
    var mode by remember { mutableStateOf(s.taskWindowMode) }
    var size by remember { mutableStateOf(s.taskWindowSize) }
    val tasks by TaskManager.tasks.collectAsState()
    val a11y = MeeraAccessibilityService.instance != null
    val fmt = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("Background tasks and floating window")
        Text(
            "Meera works while you use other apps. A small window shows what she is doing; she checks the result before saying it is done.",
            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Background tasks", fontSize = 14.sp, modifier = Modifier.weight(1f))
            Switch(checked = on, onCheckedChange = { on = it; s.tasksEnabled = it })
        }
        Text("Floating window", fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = mode == 1, onClick = { mode = 1; s.taskWindowMode = 1 }, label = { Text("Only during work", fontSize = 11.sp) })
            FilterChip(selected = mode == 0, onClick = { mode = 0; s.taskWindowMode = 0 }, label = { Text("Always", fontSize = 11.sp) })
            FilterChip(selected = mode == 2, onClick = { mode = 2; s.taskWindowMode = 2 }, label = { Text("Off", fontSize = 11.sp) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Size", fontSize = 13.sp, modifier = Modifier.padding(end = 4.dp))
            FilterChip(selected = size == 1, onClick = { size = 1; s.taskWindowSize = 1 }, label = { Text("Normal", fontSize = 11.sp) })
            FilterChip(selected = size == 0, onClick = { size = 0; s.taskWindowSize = 0 }, label = { Text("Small", fontSize = 11.sp) })
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                if (a11y) "Accessibility service: ON" else "Accessibility service: OFF (the window needs it)",
                fontSize = 13.sp, modifier = Modifier.weight(1f)
            )
            OutlinedButton(onClick = {
                try { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            }) { Text("Open") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { TaskManager.demo() }) { Text("Test (demo task)") }
            OutlinedButton(onClick = { TaskManager.clearHistory() }, enabled = tasks.any { !it.active }) { Text("Clear history") }
        }
        val past = tasks.filter { !it.active }.take(8)
        if (past.isEmpty()) {
            Text("No finished tasks yet.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            for (t in past) {
                val mark = when {
                    t.status == TStatus.DONE && t.verified -> "✅ verified"
                    t.status == TStatus.DONE -> "⚠ not verified"
                    t.status == TStatus.FAILED -> "❌ failed"
                    else -> "⏹ stopped"
                }
                Column(Modifier.fillMaxWidth()) {
                    Text(t.title, fontSize = 13.sp, maxLines = 1)
                    Text(fmt.format(Date(t.startedAt)) + "   " + mark, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
